<?php

/* NelmioApiDocBundle::Components/motd.html.twig */
class __TwigTemplate_a4a58643eab2bcc8d2198f9cca379fd728e7816130c6bd6bd75ae3c835c3bc3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b96491505bb901729a8f1b54da627a57408d47e9285ad02519553740d6e9126e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b96491505bb901729a8f1b54da627a57408d47e9285ad02519553740d6e9126e->enter($__internal_b96491505bb901729a8f1b54da627a57408d47e9285ad02519553740d6e9126e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NelmioApiDocBundle::Components/motd.html.twig"));

        $__internal_196a7748663f31baf6d3c23e76d159d2ece17ba291f117da36993ad073e0d2b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_196a7748663f31baf6d3c23e76d159d2ece17ba291f117da36993ad073e0d2b4->enter($__internal_196a7748663f31baf6d3c23e76d159d2ece17ba291f117da36993ad073e0d2b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NelmioApiDocBundle::Components/motd.html.twig"));

        // line 1
        echo "<div class=\"motd\"></div>
";
        
        $__internal_b96491505bb901729a8f1b54da627a57408d47e9285ad02519553740d6e9126e->leave($__internal_b96491505bb901729a8f1b54da627a57408d47e9285ad02519553740d6e9126e_prof);

        
        $__internal_196a7748663f31baf6d3c23e76d159d2ece17ba291f117da36993ad073e0d2b4->leave($__internal_196a7748663f31baf6d3c23e76d159d2ece17ba291f117da36993ad073e0d2b4_prof);

    }

    public function getTemplateName()
    {
        return "NelmioApiDocBundle::Components/motd.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"motd\"></div>
", "NelmioApiDocBundle::Components/motd.html.twig", "/var/www/html/Symfony.3.0.x/ApiSymfony/restApi/vendor/nelmio/api-doc-bundle/Nelmio/ApiDocBundle/Resources/views/Components/motd.html.twig");
    }
}
