<?php

/* RestBundle:Default:index.html.twig */
class __TwigTemplate_ecad6f1480549e1883b8a6e6d10c31c00543e9ffc0580f8f26204db0c833bf10 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d54f885b3d60e5fe98af8059674bbdb2173622180d138ee75cd0de6e1c0a2f1e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d54f885b3d60e5fe98af8059674bbdb2173622180d138ee75cd0de6e1c0a2f1e->enter($__internal_d54f885b3d60e5fe98af8059674bbdb2173622180d138ee75cd0de6e1c0a2f1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RestBundle:Default:index.html.twig"));

        $__internal_7b0d34610a18ff9276d5a2c0fcac77e7c6c6536c00fadbc8b847b32569078391 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b0d34610a18ff9276d5a2c0fcac77e7c6c6536c00fadbc8b847b32569078391->enter($__internal_7b0d34610a18ff9276d5a2c0fcac77e7c6c6536c00fadbc8b847b32569078391_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RestBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_d54f885b3d60e5fe98af8059674bbdb2173622180d138ee75cd0de6e1c0a2f1e->leave($__internal_d54f885b3d60e5fe98af8059674bbdb2173622180d138ee75cd0de6e1c0a2f1e_prof);

        
        $__internal_7b0d34610a18ff9276d5a2c0fcac77e7c6c6536c00fadbc8b847b32569078391->leave($__internal_7b0d34610a18ff9276d5a2c0fcac77e7c6c6536c00fadbc8b847b32569078391_prof);

    }

    public function getTemplateName()
    {
        return "RestBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "RestBundle:Default:index.html.twig", "/var/www/html/Symfony.3.0.x/ApiSymfony/restApi/src/RestBundle/Resources/views/Default/index.html.twig");
    }
}
