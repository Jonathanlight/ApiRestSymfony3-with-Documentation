<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_a3a6a13a6ed501329b31067fcbd907da966549e85471f4fba5d9d040a97e8604 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf667404068ff7458949b5956d2256961bae0a2f63222cb8905a89d7b902a438 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf667404068ff7458949b5956d2256961bae0a2f63222cb8905a89d7b902a438->enter($__internal_bf667404068ff7458949b5956d2256961bae0a2f63222cb8905a89d7b902a438_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        $__internal_0081a499b05145c8cdcdd7feb4bb1b1952000e17e91446d968d9ae0226594c95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0081a499b05145c8cdcdd7feb4bb1b1952000e17e91446d968d9ae0226594c95->enter($__internal_0081a499b05145c8cdcdd7feb4bb1b1952000e17e91446d968d9ae0226594c95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_bf667404068ff7458949b5956d2256961bae0a2f63222cb8905a89d7b902a438->leave($__internal_bf667404068ff7458949b5956d2256961bae0a2f63222cb8905a89d7b902a438_prof);

        
        $__internal_0081a499b05145c8cdcdd7feb4bb1b1952000e17e91446d968d9ae0226594c95->leave($__internal_0081a499b05145c8cdcdd7feb4bb1b1952000e17e91446d968d9ae0226594c95_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "@Twig/Exception/exception.json.twig", "/var/www/html/Symfony.3.0.x/ApiSymfony/restApi/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
