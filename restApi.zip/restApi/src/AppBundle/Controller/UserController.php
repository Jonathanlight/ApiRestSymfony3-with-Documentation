<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\View\View;
use AppBundle\Entity\User;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

class UserController extends FOSRestController
{
     /**
     * @Rest\Get("/datas")
     */
    public function getCurlAction()
    {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://reddit.com/r/gifs/top/.json?limit=10&sort=hot');
        //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $restresult = curl_exec($ch);
        curl_close($ch);

        echo "<pre>";
        var_dump($restresult);
        die();
        //echo curl_errno($ch) . '-' . curl_error($ch);

        curl_close($ch);
        if ($restresult === null) {
          return new View("there are no users exist", Response::HTTP_NOT_FOUND);
        }
        return $restresult;
    }



}
