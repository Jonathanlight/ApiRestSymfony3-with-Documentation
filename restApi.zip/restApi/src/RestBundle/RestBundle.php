<?php

namespace RestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RestBundle extends Bundle
{
}
