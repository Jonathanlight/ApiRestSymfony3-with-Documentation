<?php

namespace RestBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\View\View;
use RestBundle\Entity\Utilisateur;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;

class DefaultController extends Controller
{
    /**
     * @Route("/")
     */
    public function indexAction()
    {
        return $this->render('RestBundle:Default:index.html.twig');
    }

    /**
     * @ApiDoc(
     *    description="Afficher les objets de la databases",
     *    input={"class"=UtilisateurType::class, "name"=""},
     *    statusCodes = {
     *        200 = "Géneration des données avec succès",
     *        500 = "Error https"
     *    },
     *    responseMap={
     *         200 = {"class"=Utilisateur::class, "groups"={"Utilisateur"}},
     *         500 = { "class"=UtilisateurType::class, "form_errors"=true, "name" = ""}
     *    }
     * )
     *
     * @Rest\View(statusCode=Response::HTTP_CREATED)
     * @Rest\Get("/utilisateur")
     */
    public function getsAction()
    {
      $restresult = $this->getDoctrine()->getRepository('RestBundle:Utilisateur')->findAll();
        if ($restresult === null) {
          return new View("there are no users exist", Response::HTTP_NOT_FOUND);
        }
        return $restresult;
    }


    /**
      * @ApiDoc(
      *    description="Recherche un utilisateur par l'id ",
      *    input={"class"=UtilisateurType::class, "name"=""},
      *    statusCodes = {
      *        200 = "Géneration des données avec succès",
      *        500 = "Error https"
      *    }
      * )
      *
      * @Rest\View(statusCode=Response::HTTP_CREATED)
      * @Rest\Get("/utilisateur/{id}")
     */
     public function idsAction($id)
     {
       $singleresult = $this->getDoctrine()->getRepository('RestBundle:Utilisateur')->find($id);
       if ($singleresult === null) {
         return new View("user not found", Response::HTTP_NOT_FOUND);
       }
       return $singleresult;
     }


    /**
     * @ApiDoc(
     *    description="Route pour tester la connexion utilisateur",
     *    input={"class"=UtilisateurType::class, "name"=""},
     *    statusCodes = {
     *        200 = "Géneration des données avec succès",
     *        500 = "Error https"
     *    }
     * )
     * @Rest\View(statusCode=Response::HTTP_CREATED)
     * @Rest\Post("/connexion")
     */
     public function connexionAction(Request $request)
     {

       $username = $request->get('username');
       $password = $request->get('password');

       if(empty($username) || empty($password)) {
         return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_ACCEPTABLE);
       } else {
           $restresult = $this->getDoctrine()->getRepository('RestBundle:Utilisateur')
           ->findBy(['username'=>$username]);
           if($restresult) {
               $pass = $restresult[0]->getPassword();
                if (password_verify($password, $pass)) {
                    return 'Password is valid!';
                } else {
                    return new View("Password Invalid", Response::HTTP_NOT_ACCEPTABLE);
                }
           } else {
               return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_ACCEPTABLE);
           }
       }

     }


    /**
     * @ApiDoc(
     *    description="Route pour inscrire un utilisateur",
     *    input={"class"=UtilisateurType::class, "name"=""},
     *    statusCodes = {
     *        200 = "Insertion des données avec succès",
     *        500 = "Error https"
     *    }
     * )
     * @Rest\View(statusCode=Response::HTTP_CREATED)
     * @Rest\Post("/inscription")
     */
     public function postAction(Request $request)
     {
       $data = new Utilisateur;
       $username = $request->get('username');
       $password = $request->get('password');
       $email    = $request->get('email');
       $phone    = $request->get('phone');

       if(empty($username) || empty($password) || empty($email)) {
         return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_ACCEPTABLE);
       } else {

         $encoder = $this->container->get('security.password_encoder');
         $passcrypter = $encoder->encodePassword($data, $password);
         $data->setUsername($username);
         $data->setPassword($passcrypter);
         $data->setEmail($email);
         $data->setPhone($phone);
         $data->setStatus(1);
         $data->setRoles(['ROLE_USER']);
         $em = $this->getDoctrine()->getManager();
         $em->persist($data);
         $em->flush();

         return new View("Utilisateur Added Successfully", Response::HTTP_OK);
       }
 
     }



    /**
     * @ApiDoc(
     *    description="Modifier un utilisateur",
     *    input={"class"=UtilisateurType::class, "name"=""},
     *    statusCodes = {
     *        200 = "Des données supprimer avec succès",
     *        500 = "Error https"
     *    }
     * )
     * @Rest\View(statusCode=Response::HTTP_CREATED)
     * @Rest\Put("/utilisateur/{id}")
     */
     public function updateAction($id,Request $request)
     {
       $data = new Utilisateur;
       $username = $request->get('username');
       $password = $request->get('password');
       $email    = $request->get('email');
       $phone    = $request->get('phone');

       $em = $this->getDoctrine()->getManager();
       $user = $this->getDoctrine()->getRepository('RestBundle:Utilisateur')->find($id);
          if (empty($user)) {
             return new View("user not found", Response::HTTP_NOT_FOUND);
           }elseif(!empty($username) && !empty($password) && !empty($email) && !empty($phone)){
                $encoder = $this->container->get('security.password_encoder');
                $passcrypter = $encoder->encodePassword($data, $password);
                $user->setUsername($username);
                $user->setPassword($passcrypter);
                $user->setEmail($email);
                $user->setPhone($phone);
                $em->flush();
                return new View("User Updated Successfully", Response::HTTP_OK);
          }elseif(!empty($username) && empty($password) && empty($email) && empty($phone)){
                $user->setUsername($username);
                $em->flush();
                return new View("role Updated Successfully", Response::HTTP_OK);
          }elseif(empty($username) && !empty($password) && empty($email) && empty($phone)){
                $encoder = $this->container->get('security.password_encoder');
                $passcrypter = $encoder->encodePassword($data, $password);
                $user->setPassword($passcrypter);
                $em->flush();
                return new View("User Name Updated Successfully", Response::HTTP_OK);
          }elseif(empty($username) && empty($password) && !empty($email) && empty($phone)){
                $user->setEmail($email);
                $em->flush();
                return new View("User Email Updated Successfully", Response::HTTP_OK);
          }elseif(empty($username) && empty($password) && empty($email) && !empty($phone)){
                $user->setPhone($phone);
                $em->flush();
                return new View("User Phone Updated Successfully", Response::HTTP_OK);
          }else{
           return new View("User name or role cannot be empty", Response::HTTP_NOT_ACCEPTABLE);
         }

     }


    /**
     * @ApiDoc(
     *    description="Supprimer un utilisateur",
     *    input={"class"=UtilisateurType::class, "name"=""},
     *    statusCodes = {
     *        200 = "Des données supprimer avec succès",
     *        500 = "Error https"
     *    }
     * )
     * @Rest\View(statusCode=Response::HTTP_CREATED)
     * @Rest\Delete("/utilisateur/{id}")
     */
     public function deleteAction($id)
     {
      $data = new Utilisateur;
      $sn = $this->getDoctrine()->getManager();
      $user = $this->getDoctrine()->getRepository('RestBundle:Utilisateur')->find($id);
      if (empty($user)) {
        return new View("user not found", Response::HTTP_NOT_FOUND);
       }else {
        $sn->remove($user);
        $sn->flush();
       }
      return new View("deleted successfully", Response::HTTP_OK);
     }

}
